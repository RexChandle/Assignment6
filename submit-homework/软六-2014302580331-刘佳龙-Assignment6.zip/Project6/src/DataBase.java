
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
 
 
public class DataBase {
    public static void main(String[] args) throws Exception {
        Connection conn = null;
        String sql;
       
        String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
 
        try {
            
            Class.forName("com.mysql.jdbc.Driver");// ��̬����mysql����
    
 
            System.out.println("�ɹ�����MySQL��������");
            // Connection���ݿ�����
            conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            sql = "create table pet";
            int result = stmt.executeUpdate(sql);// �������-1��û�гɹ�
            if (result != -1) {
          
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    System.out.println(rs.getString(1) + "\t" + rs.getString(2));
                }
            }
        } catch (SQLException e) {
            System.out.println("MySQL��������");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.close();
        }
 
    }
 
}