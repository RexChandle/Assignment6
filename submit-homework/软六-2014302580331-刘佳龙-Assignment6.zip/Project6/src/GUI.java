import java.awt.BorderLayout;
import java.awt.Desktop.Action;
import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JRadioButton;

import java.awt.Button;
import java.awt.Color;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JTextPane;


public class GUI extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
//	//�������������ã�
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					GUI frame = new GUI();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
	/**
	 * Create the frame.
	 */
	int price = 0;
	public GUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 576, 422);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JRadioButton rdbtnMo = new JRadioButton("\u732B                     300");
		rdbtnMo.setBounds(45, 37, 315, 43);
		contentPane.add(rdbtnMo);
		rdbtnMo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				price +=300;
			}
		});
		
		
		JRadioButton radioButton = new JRadioButton("\u72D7                     400");
		radioButton.setBounds(45, 96, 315, 43);
		contentPane.add(radioButton);
		radioButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				price +=400;
			}
		});
		
		JRadioButton radioButton_1 = new JRadioButton("\u5154                     86");
		radioButton_1.setBounds(45, 156, 315, 43);
		contentPane.add(radioButton_1);
		radioButton_1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				price +=86;
			}
		});
		
		JRadioButton radioButton_2 = new JRadioButton("\u9C7C                     30");
		radioButton_2.setBounds(45, 204, 315, 43);
		contentPane.add(radioButton_2);
		radioButton_2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				price +=30;
			}
		});
		
		
		
		JButton button = new JButton("\u786E\u8BA4\u4E0B\u5355");
		button.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
			JOptionPane.showInputDialog(
						price);
				
			}
		});
		button.setBounds(384, 278, 113, 27);
		contentPane.add(button);
		
		JTextPane txtpnPrice = new JTextPane();
		txtpnPrice.setText("PRICE");
		txtpnPrice.setBounds(162, 13, 47, 24);
		contentPane.add(txtpnPrice);
		
		JButton button_1 = new JButton("\u9000\u51FA");
		button_1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				
				contentPane.setVisible(false);
				}
		});
		button_1.setBounds(384, 335, 113, 27);
		contentPane.add(button_1);
	}
}
