
public class Animal {
	private int price;
	private String name;
	private String interest;
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getInterest() {
		return interest;
	}
	public void setInterest(String interest) {
		this.interest = interest;
	}
	public Animal(int price, String name, String interest) {
		super();
		this.price = price;
		this.name = name;
		this.interest = interest;
	}
	public Animal() {
		super();
		// TODO Auto-generated constructor stub
	}
}
class Dog extends Animal{
	public void setPrice(int price) {
		price = 30000;
	}
	public void setName(String name) {
		name = "����";
	}
	public void setInterest(String interest) {
		interest = "����";
	}
}

class Cat extends Animal{
	public void setPrice(int price) {
		price = 3000;
	}
	public void setName(String name) {
		name = "��˹";
	}
	public void setInterest(String interest) {
		interest = "����";
	}
}

class goldfish extends Animal{
	public void setPrice(int price) {
		price = 30;
	}
	public void setName(String name) {
		name = "����";
	}
	public void setInterest(String interest) {
		interest = "����";
	}
}

class rabbit extends Animal{
	public void setPrice(int price) {
		price = 300;
	}
	public void setName(String name) {
		name = "��˿��";
	}
	public void setInterest(String interest) {
		interest = "����";
	}
}

